def get_message():
    return "Welcome to K9"
